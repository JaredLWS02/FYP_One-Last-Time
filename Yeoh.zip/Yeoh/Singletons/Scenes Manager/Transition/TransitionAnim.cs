using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TransitionAnim : MonoBehaviour
{
    // AudioSource staticLoop;

    // public void SfxPlayStaticLoop()
    // {
    //     AudioManager.Current.StopLoop(staticLoop);

    //     staticLoop = AudioManager.Current.LoopSFX(gameObject, SFXManager.Current.sfxStaticLoop, false);
    // }

    // public void SfxStopStaticLoop()
    // {
    //     AudioManager.Current.StopLoop(staticLoop);
    // }
}
