
public class State_Hub : BaseState
{
    public override string Name => "Hub";

    // this state is where all states can return to and switch to another

    public State_Hub()
    {
    }

    protected override void OnEnter()
    {
    }

    protected override void OnUpdate(float deltaTime)
    {
    }

    protected override void OnExit()
    {
    }
}
